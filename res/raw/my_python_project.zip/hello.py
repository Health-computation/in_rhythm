import android, time
import datetime
import os
import dbmerge
#import pandas as pd
# import pandas as pd

droid = android.Android()
droid.makeToast("TEST")
#list_of_files = os.listdir("/storage/sdcard0/edu.cornell.cs.pac.sensiphone/default/archive/")[0]
#droid.makeToast(list_of_files)


try:
    os.chdir("/storage/sdcard0/edu.cornell.cs.pac.sensiphone/default/backup/")
    dbmerge.merge()
    import db2csv
    import glob
    for file in glob.glob("*.db"):
        droid.makeToast(file)
        db2csv.convert(file,"/storage/sdcard0/edu.cornell.cs.pac.sensiphone/default/backup/") 
        os.rename(file, file + "-converted")
        droid.makeToast("File converted.")



except Exception, e:
    droid.makeToast(str(e))

#while 1:
#    droid.makeToast(dbmerge.__file__)
##    time.sleep(5)
